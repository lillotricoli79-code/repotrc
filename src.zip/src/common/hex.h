#pragma once
#include <string>
#include <vector>
#include <sstream>
#include <iomanip>

namespace common {
  inline std::string to_hex(const std::vector<uint8_t>& data) {
    std::ostringstream oss;
    for (auto b : data)
      oss << std::hex << std::setw(2) << std::setfill('0') << (int)b;
    return oss.str();
  }

  inline std::vector<uint8_t> from_hex(const std::string& hex) {
    std::vector<uint8_t> out;
    for (size_t i = 0; i < hex.size(); i += 2) {
      std::string byteString = hex.substr(i, 2);
      uint8_t byte = (uint8_t) strtol(byteString.c_str(), nullptr, 16);
      out.push_back(byte);
    }
    return out;
  }
}
