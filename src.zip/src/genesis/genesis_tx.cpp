#include <iostream>
#include <string>

#include "cryptonote_basic/cryptonote_basic.h"
#include "cryptonote_core/cryptonote_tx_utils.h"
#include "common/hex.h"
#include "string_tools.h"

using namespace cryptonote;

int main(int argc, char** argv) {
    if (argc < 3) {
        std::cerr << "Usage: genesis <address> <reward>\n";
        return 1;
    }

    std::string addr_str = argv[1];
    uint64_t reward = std::strtoull(argv[2], nullptr, 10);

    // Parse TRC address
    address_parse_info info;
    if (!get_account_address_from_str(info, MAINNET, addr_str)) {
        std::cerr << "Invalid address!\n";
        return 1;
    }

    transaction miner_tx;

    // CALL with parameters matching YOUR cryptonote_tx_utils.h
    bool r = construct_miner_tx(
        0,                 // height
        0,                 // median_weight
        0,                 // already_generated_coins
        0,                 // current_block_weight
        0,                 // fee (zero)
        info.address,      // miner reward address
        miner_tx,          // out
        blobdata(),        // extra nonce
        1,                 // max outs
        1                  // HF version
    );

    if (!r) {
        std::cerr << "construct_miner_tx failed\n";
        return 1;
    }

    // Override the reward manually (GENESIS ONLY)
    if (!miner_tx.vout.empty()) {
        miner_tx.vout[0].amount = reward;
    } else {
        std::cerr << "miner_tx has no outputs!\n";
        return 1;
    }

    // Serialize TX
    std::string tx_hex = epee::string_tools::buff_to_hex_nodelimer(
        t_serializable_object_to_blob(miner_tx)
    );

    std::cout << "\nGENESIS_TX_HEX:\n" << tx_hex << "\n";
    return 0;
}
