#ifndef CRYPTONIGHTR_TEMPLATE_H
#define CRYPTONIGHTR_TEMPLATE_H

#if defined __i386 || defined __x86_64__

void CryptonightR_instruction0(void);
void CryptonightR_instruction1(void);
void CryptonightR_instruction2(void);
void CryptonightR_instruction3(void);
void CryptonightR_instruction4(void);
void CryptonightR_instruction5(void);
void CryptonightR_instruction6(void);
void CryptonightR_instruction7(void);
void CryptonightR_instruction8(void);
void CryptonightR_instruction9(void);
void CryptonightR_instruction10(void);
void CryptonightR_instruction11(void);
void CryptonightR_instruction12(void);
void CryptonightR_instruction13(void);
void CryptonightR_instruction14(void);
void CryptonightR_instruction15(void);
void CryptonightR_instruction16(void);
void CryptonightR_instruction17(void);
void CryptonightR_instruction18(void);
void CryptonightR_instruction19(void);
void CryptonightR_instruction20(void);
void CryptonightR_instruction21(void);
void CryptonightR_instruction22(void);
void CryptonightR_instruction23(void);
void CryptonightR_instruction24(void);
void CryptonightR_instruction25(void);
void CryptonightR_instruction26(void);
void CryptonightR_instruction27(void);
void CryptonightR_instruction28(void);
void CryptonightR_instruction29(void);
void CryptonightR_instruction30(void);
void CryptonightR_instruction31(void);
void CryptonightR_instruction32(void);
void CryptonightR_instruction33(void);
void CryptonightR_instruction34(void);
void CryptonightR_instruction35(void);
void CryptonightR_instruction36(void);
void CryptonightR_instruction37(void);
void CryptonightR_instruction38(void);
void CryptonightR_instruction39(void);
void CryptonightR_instruction40(void);
void CryptonightR_instruction41(void);
void CryptonightR_instruction42(void);
void CryptonightR_instruction43(void);
void CryptonightR_instruction44(void);
void CryptonightR_instruction45(void);
void CryptonightR_instruction46(void);
void CryptonightR_instruction47(void);
void CryptonightR_instruction48(void);
void CryptonightR_instruction49(void);
void CryptonightR_instruction50(void);
void CryptonightR_instruction51(void);
void CryptonightR_instruction52(void);
void CryptonightR_instruction53(void);
void CryptonightR_instruction54(void);
void CryptonightR_instruction55(void);
void CryptonightR_instruction56(void);
void CryptonightR_instruction57(void);
void CryptonightR_instruction58(void);
void CryptonightR_instruction59(void);
void CryptonightR_instruction60(void);
void CryptonightR_instruction61(void);
void CryptonightR_instruction62(void);
void CryptonightR_instruction63(void);
void CryptonightR_instruction64(void);
void CryptonightR_instruction65(void);
void CryptonightR_instruction66(void);
void CryptonightR_instruction67(void);
void CryptonightR_instruction68(void);
void CryptonightR_instruction69(void);
void CryptonightR_instruction70(void);
void CryptonightR_instruction71(void);
void CryptonightR_instruction72(void);
void CryptonightR_instruction73(void);
void CryptonightR_instruction74(void);
void CryptonightR_instruction75(void);
void CryptonightR_instruction76(void);
void CryptonightR_instruction77(void);
void CryptonightR_instruction78(void);
void CryptonightR_instruction79(void);
void CryptonightR_instruction80(void);
void CryptonightR_instruction81(void);
void CryptonightR_instruction82(void);
void CryptonightR_instruction83(void);
void CryptonightR_instruction84(void);
void CryptonightR_instruction85(void);
void CryptonightR_instruction86(void);
void CryptonightR_instruction87(void);
void CryptonightR_instruction88(void);
void CryptonightR_instruction89(void);
void CryptonightR_instruction90(void);
void CryptonightR_instruction91(void);
void CryptonightR_instruction92(void);
void CryptonightR_instruction93(void);
void CryptonightR_instruction94(void);
void CryptonightR_instruction95(void);
void CryptonightR_instruction96(void);
void CryptonightR_instruction97(void);
void CryptonightR_instruction98(void);
void CryptonightR_instruction99(void);
void CryptonightR_instruction100(void);
void CryptonightR_instruction101(void);
void CryptonightR_instruction102(void);
void CryptonightR_instruction103(void);
void CryptonightR_instruction104(void);
void CryptonightR_instruction105(void);
void CryptonightR_instruction106(void);
void CryptonightR_instruction107(void);
void CryptonightR_instruction108(void);
void CryptonightR_instruction109(void);
void CryptonightR_instruction110(void);
void CryptonightR_instruction111(void);
void CryptonightR_instruction112(void);
void CryptonightR_instruction113(void);
void CryptonightR_instruction114(void);
void CryptonightR_instruction115(void);
void CryptonightR_instruction116(void);
void CryptonightR_instruction117(void);
void CryptonightR_instruction118(void);
void CryptonightR_instruction119(void);
void CryptonightR_instruction120(void);
void CryptonightR_instruction121(void);
void CryptonightR_instruction122(void);
void CryptonightR_instruction123(void);
void CryptonightR_instruction124(void);
void CryptonightR_instruction125(void);
void CryptonightR_instruction126(void);
void CryptonightR_instruction127(void);
void CryptonightR_instruction128(void);
void CryptonightR_instruction129(void);
void CryptonightR_instruction130(void);
void CryptonightR_instruction131(void);
void CryptonightR_instruction132(void);
void CryptonightR_instruction133(void);
void CryptonightR_instruction134(void);
void CryptonightR_instruction135(void);
void CryptonightR_instruction136(void);
void CryptonightR_instruction137(void);
void CryptonightR_instruction138(void);
void CryptonightR_instruction139(void);
void CryptonightR_instruction140(void);
void CryptonightR_instruction141(void);
void CryptonightR_instruction142(void);
void CryptonightR_instruction143(void);
void CryptonightR_instruction144(void);
void CryptonightR_instruction145(void);
void CryptonightR_instruction146(void);
void CryptonightR_instruction147(void);
void CryptonightR_instruction148(void);
void CryptonightR_instruction149(void);
void CryptonightR_instruction150(void);
void CryptonightR_instruction151(void);
void CryptonightR_instruction152(void);
void CryptonightR_instruction153(void);
void CryptonightR_instruction154(void);
void CryptonightR_instruction155(void);
void CryptonightR_instruction156(void);
void CryptonightR_instruction157(void);
void CryptonightR_instruction158(void);
void CryptonightR_instruction159(void);
void CryptonightR_instruction160(void);
void CryptonightR_instruction161(void);
void CryptonightR_instruction162(void);
void CryptonightR_instruction163(void);
void CryptonightR_instruction164(void);
void CryptonightR_instruction165(void);
void CryptonightR_instruction166(void);
void CryptonightR_instruction167(void);
void CryptonightR_instruction168(void);
void CryptonightR_instruction169(void);
void CryptonightR_instruction170(void);
void CryptonightR_instruction171(void);
void CryptonightR_instruction172(void);
void CryptonightR_instruction173(void);
void CryptonightR_instruction174(void);
void CryptonightR_instruction175(void);
void CryptonightR_instruction176(void);
void CryptonightR_instruction177(void);
void CryptonightR_instruction178(void);
void CryptonightR_instruction179(void);
void CryptonightR_instruction180(void);
void CryptonightR_instruction181(void);
void CryptonightR_instruction182(void);
void CryptonightR_instruction183(void);
void CryptonightR_instruction184(void);
void CryptonightR_instruction185(void);
void CryptonightR_instruction186(void);
void CryptonightR_instruction187(void);
void CryptonightR_instruction188(void);
void CryptonightR_instruction189(void);
void CryptonightR_instruction190(void);
void CryptonightR_instruction191(void);
void CryptonightR_instruction192(void);
void CryptonightR_instruction193(void);
void CryptonightR_instruction194(void);
void CryptonightR_instruction195(void);
void CryptonightR_instruction196(void);
void CryptonightR_instruction197(void);
void CryptonightR_instruction198(void);
void CryptonightR_instruction199(void);
void CryptonightR_instruction200(void);
void CryptonightR_instruction201(void);
void CryptonightR_instruction202(void);
void CryptonightR_instruction203(void);
void CryptonightR_instruction204(void);
void CryptonightR_instruction205(void);
void CryptonightR_instruction206(void);
void CryptonightR_instruction207(void);
void CryptonightR_instruction208(void);
void CryptonightR_instruction209(void);
void CryptonightR_instruction210(void);
void CryptonightR_instruction211(void);
void CryptonightR_instruction212(void);
void CryptonightR_instruction213(void);
void CryptonightR_instruction214(void);
void CryptonightR_instruction215(void);
void CryptonightR_instruction216(void);
void CryptonightR_instruction217(void);
void CryptonightR_instruction218(void);
void CryptonightR_instruction219(void);
void CryptonightR_instruction220(void);
void CryptonightR_instruction221(void);
void CryptonightR_instruction222(void);
void CryptonightR_instruction223(void);
void CryptonightR_instruction224(void);
void CryptonightR_instruction225(void);
void CryptonightR_instruction226(void);
void CryptonightR_instruction227(void);
void CryptonightR_instruction228(void);
void CryptonightR_instruction229(void);
void CryptonightR_instruction230(void);
void CryptonightR_instruction231(void);
void CryptonightR_instruction232(void);
void CryptonightR_instruction233(void);
void CryptonightR_instruction234(void);
void CryptonightR_instruction235(void);
void CryptonightR_instruction236(void);
void CryptonightR_instruction237(void);
void CryptonightR_instruction238(void);
void CryptonightR_instruction239(void);
void CryptonightR_instruction240(void);
void CryptonightR_instruction241(void);
void CryptonightR_instruction242(void);
void CryptonightR_instruction243(void);
void CryptonightR_instruction244(void);
void CryptonightR_instruction245(void);
void CryptonightR_instruction246(void);
void CryptonightR_instruction247(void);
void CryptonightR_instruction248(void);
void CryptonightR_instruction249(void);
void CryptonightR_instruction250(void);
void CryptonightR_instruction251(void);
void CryptonightR_instruction252(void);
void CryptonightR_instruction253(void);
void CryptonightR_instruction254(void);
void CryptonightR_instruction255(void);
void CryptonightR_instruction256(void);
void CryptonightR_instruction_mov0(void);
void CryptonightR_instruction_mov1(void);
void CryptonightR_instruction_mov2(void);
void CryptonightR_instruction_mov3(void);
void CryptonightR_instruction_mov4(void);
void CryptonightR_instruction_mov5(void);
void CryptonightR_instruction_mov6(void);
void CryptonightR_instruction_mov7(void);
void CryptonightR_instruction_mov8(void);
void CryptonightR_instruction_mov9(void);
void CryptonightR_instruction_mov10(void);
void CryptonightR_instruction_mov11(void);
void CryptonightR_instruction_mov12(void);
void CryptonightR_instruction_mov13(void);
void CryptonightR_instruction_mov14(void);
void CryptonightR_instruction_mov15(void);
void CryptonightR_instruction_mov16(void);
void CryptonightR_instruction_mov17(void);
void CryptonightR_instruction_mov18(void);
void CryptonightR_instruction_mov19(void);
void CryptonightR_instruction_mov20(void);
void CryptonightR_instruction_mov21(void);
void CryptonightR_instruction_mov22(void);
void CryptonightR_instruction_mov23(void);
void CryptonightR_instruction_mov24(void);
void CryptonightR_instruction_mov25(void);
void CryptonightR_instruction_mov26(void);
void CryptonightR_instruction_mov27(void);
void CryptonightR_instruction_mov28(void);
void CryptonightR_instruction_mov29(void);
void CryptonightR_instruction_mov30(void);
void CryptonightR_instruction_mov31(void);
void CryptonightR_instruction_mov32(void);
void CryptonightR_instruction_mov33(void);
void CryptonightR_instruction_mov34(void);
void CryptonightR_instruction_mov35(void);
void CryptonightR_instruction_mov36(void);
void CryptonightR_instruction_mov37(void);
void CryptonightR_instruction_mov38(void);
void CryptonightR_instruction_mov39(void);
void CryptonightR_instruction_mov40(void);
void CryptonightR_instruction_mov41(void);
void CryptonightR_instruction_mov42(void);
void CryptonightR_instruction_mov43(void);
void CryptonightR_instruction_mov44(void);
void CryptonightR_instruction_mov45(void);
void CryptonightR_instruction_mov46(void);
void CryptonightR_instruction_mov47(void);
void CryptonightR_instruction_mov48(void);
void CryptonightR_instruction_mov49(void);
void CryptonightR_instruction_mov50(void);
void CryptonightR_instruction_mov51(void);
void CryptonightR_instruction_mov52(void);
void CryptonightR_instruction_mov53(void);
void CryptonightR_instruction_mov54(void);
void CryptonightR_instruction_mov55(void);
void CryptonightR_instruction_mov56(void);
void CryptonightR_instruction_mov57(void);
void CryptonightR_instruction_mov58(void);
void CryptonightR_instruction_mov59(void);
void CryptonightR_instruction_mov60(void);
void CryptonightR_instruction_mov61(void);
void CryptonightR_instruction_mov62(void);
void CryptonightR_instruction_mov63(void);
void CryptonightR_instruction_mov64(void);
void CryptonightR_instruction_mov65(void);
void CryptonightR_instruction_mov66(void);
void CryptonightR_instruction_mov67(void);
void CryptonightR_instruction_mov68(void);
void CryptonightR_instruction_mov69(void);
void CryptonightR_instruction_mov70(void);
void CryptonightR_instruction_mov71(void);
void CryptonightR_instruction_mov72(void);
void CryptonightR_instruction_mov73(void);
void CryptonightR_instruction_mov74(void);
void CryptonightR_instruction_mov75(void);
void CryptonightR_instruction_mov76(void);
void CryptonightR_instruction_mov77(void);
void CryptonightR_instruction_mov78(void);
void CryptonightR_instruction_mov79(void);
void CryptonightR_instruction_mov80(void);
void CryptonightR_instruction_mov81(void);
void CryptonightR_instruction_mov82(void);
void CryptonightR_instruction_mov83(void);
void CryptonightR_instruction_mov84(void);
void CryptonightR_instruction_mov85(void);
void CryptonightR_instruction_mov86(void);
void CryptonightR_instruction_mov87(void);
void CryptonightR_instruction_mov88(void);
void CryptonightR_instruction_mov89(void);
void CryptonightR_instruction_mov90(void);
void CryptonightR_instruction_mov91(void);
void CryptonightR_instruction_mov92(void);
void CryptonightR_instruction_mov93(void);
void CryptonightR_instruction_mov94(void);
void CryptonightR_instruction_mov95(void);
void CryptonightR_instruction_mov96(void);
void CryptonightR_instruction_mov97(void);
void CryptonightR_instruction_mov98(void);
void CryptonightR_instruction_mov99(void);
void CryptonightR_instruction_mov100(void);
void CryptonightR_instruction_mov101(void);
void CryptonightR_instruction_mov102(void);
void CryptonightR_instruction_mov103(void);
void CryptonightR_instruction_mov104(void);
void CryptonightR_instruction_mov105(void);
void CryptonightR_instruction_mov106(void);
void CryptonightR_instruction_mov107(void);
void CryptonightR_instruction_mov108(void);
void CryptonightR_instruction_mov109(void);
void CryptonightR_instruction_mov110(void);
void CryptonightR_instruction_mov111(void);
void CryptonightR_instruction_mov112(void);
void CryptonightR_instruction_mov113(void);
void CryptonightR_instruction_mov114(void);
void CryptonightR_instruction_mov115(void);
void CryptonightR_instruction_mov116(void);
void CryptonightR_instruction_mov117(void);
void CryptonightR_instruction_mov118(void);
void CryptonightR_instruction_mov119(void);
void CryptonightR_instruction_mov120(void);
void CryptonightR_instruction_mov121(void);
void CryptonightR_instruction_mov122(void);
void CryptonightR_instruction_mov123(void);
void CryptonightR_instruction_mov124(void);
void CryptonightR_instruction_mov125(void);
void CryptonightR_instruction_mov126(void);
void CryptonightR_instruction_mov127(void);
void CryptonightR_instruction_mov128(void);
void CryptonightR_instruction_mov129(void);
void CryptonightR_instruction_mov130(void);
void CryptonightR_instruction_mov131(void);
void CryptonightR_instruction_mov132(void);
void CryptonightR_instruction_mov133(void);
void CryptonightR_instruction_mov134(void);
void CryptonightR_instruction_mov135(void);
void CryptonightR_instruction_mov136(void);
void CryptonightR_instruction_mov137(void);
void CryptonightR_instruction_mov138(void);
void CryptonightR_instruction_mov139(void);
void CryptonightR_instruction_mov140(void);
void CryptonightR_instruction_mov141(void);
void CryptonightR_instruction_mov142(void);
void CryptonightR_instruction_mov143(void);
void CryptonightR_instruction_mov144(void);
void CryptonightR_instruction_mov145(void);
void CryptonightR_instruction_mov146(void);
void CryptonightR_instruction_mov147(void);
void CryptonightR_instruction_mov148(void);
void CryptonightR_instruction_mov149(void);
void CryptonightR_instruction_mov150(void);
void CryptonightR_instruction_mov151(void);
void CryptonightR_instruction_mov152(void);
void CryptonightR_instruction_mov153(void);
void CryptonightR_instruction_mov154(void);
void CryptonightR_instruction_mov155(void);
void CryptonightR_instruction_mov156(void);
void CryptonightR_instruction_mov157(void);
void CryptonightR_instruction_mov158(void);
void CryptonightR_instruction_mov159(void);
void CryptonightR_instruction_mov160(void);
void CryptonightR_instruction_mov161(void);
void CryptonightR_instruction_mov162(void);
void CryptonightR_instruction_mov163(void);
void CryptonightR_instruction_mov164(void);
void CryptonightR_instruction_mov165(void);
void CryptonightR_instruction_mov166(void);
void CryptonightR_instruction_mov167(void);
void CryptonightR_instruction_mov168(void);
void CryptonightR_instruction_mov169(void);
void CryptonightR_instruction_mov170(void);
void CryptonightR_instruction_mov171(void);
void CryptonightR_instruction_mov172(void);
void CryptonightR_instruction_mov173(void);
void CryptonightR_instruction_mov174(void);
void CryptonightR_instruction_mov175(void);
void CryptonightR_instruction_mov176(void);
void CryptonightR_instruction_mov177(void);
void CryptonightR_instruction_mov178(void);
void CryptonightR_instruction_mov179(void);
void CryptonightR_instruction_mov180(void);
void CryptonightR_instruction_mov181(void);
void CryptonightR_instruction_mov182(void);
void CryptonightR_instruction_mov183(void);
void CryptonightR_instruction_mov184(void);
void CryptonightR_instruction_mov185(void);
void CryptonightR_instruction_mov186(void);
void CryptonightR_instruction_mov187(void);
void CryptonightR_instruction_mov188(void);
void CryptonightR_instruction_mov189(void);
void CryptonightR_instruction_mov190(void);
void CryptonightR_instruction_mov191(void);
void CryptonightR_instruction_mov192(void);
void CryptonightR_instruction_mov193(void);
void CryptonightR_instruction_mov194(void);
void CryptonightR_instruction_mov195(void);
void CryptonightR_instruction_mov196(void);
void CryptonightR_instruction_mov197(void);
void CryptonightR_instruction_mov198(void);
void CryptonightR_instruction_mov199(void);
void CryptonightR_instruction_mov200(void);
void CryptonightR_instruction_mov201(void);
void CryptonightR_instruction_mov202(void);
void CryptonightR_instruction_mov203(void);
void CryptonightR_instruction_mov204(void);
void CryptonightR_instruction_mov205(void);
void CryptonightR_instruction_mov206(void);
void CryptonightR_instruction_mov207(void);
void CryptonightR_instruction_mov208(void);
void CryptonightR_instruction_mov209(void);
void CryptonightR_instruction_mov210(void);
void CryptonightR_instruction_mov211(void);
void CryptonightR_instruction_mov212(void);
void CryptonightR_instruction_mov213(void);
void CryptonightR_instruction_mov214(void);
void CryptonightR_instruction_mov215(void);
void CryptonightR_instruction_mov216(void);
void CryptonightR_instruction_mov217(void);
void CryptonightR_instruction_mov218(void);
void CryptonightR_instruction_mov219(void);
void CryptonightR_instruction_mov220(void);
void CryptonightR_instruction_mov221(void);
void CryptonightR_instruction_mov222(void);
void CryptonightR_instruction_mov223(void);
void CryptonightR_instruction_mov224(void);
void CryptonightR_instruction_mov225(void);
void CryptonightR_instruction_mov226(void);
void CryptonightR_instruction_mov227(void);
void CryptonightR_instruction_mov228(void);
void CryptonightR_instruction_mov229(void);
void CryptonightR_instruction_mov230(void);
void CryptonightR_instruction_mov231(void);
void CryptonightR_instruction_mov232(void);
void CryptonightR_instruction_mov233(void);
void CryptonightR_instruction_mov234(void);
void CryptonightR_instruction_mov235(void);
void CryptonightR_instruction_mov236(void);
void CryptonightR_instruction_mov237(void);
void CryptonightR_instruction_mov238(void);
void CryptonightR_instruction_mov239(void);
void CryptonightR_instruction_mov240(void);
void CryptonightR_instruction_mov241(void);
void CryptonightR_instruction_mov242(void);
void CryptonightR_instruction_mov243(void);
void CryptonightR_instruction_mov244(void);
void CryptonightR_instruction_mov245(void);
void CryptonightR_instruction_mov246(void);
void CryptonightR_instruction_mov247(void);
void CryptonightR_instruction_mov248(void);
void CryptonightR_instruction_mov249(void);
void CryptonightR_instruction_mov250(void);
void CryptonightR_instruction_mov251(void);
void CryptonightR_instruction_mov252(void);
void CryptonightR_instruction_mov253(void);
void CryptonightR_instruction_mov254(void);
void CryptonightR_instruction_mov255(void);
void CryptonightR_instruction_mov256(void);

const void* instructions[257] = {
	(const void* ) CryptonightR_instruction0,
	(const void* ) CryptonightR_instruction1,
	(const void* ) CryptonightR_instruction2,
	(const void* ) CryptonightR_instruction3,
	(const void* ) CryptonightR_instruction4,
	(const void* ) CryptonightR_instruction5,
	(const void* ) CryptonightR_instruction6,
	(const void* ) CryptonightR_instruction7,
	(const void* ) CryptonightR_instruction8,
	(const void* ) CryptonightR_instruction9,
	(const void* ) CryptonightR_instruction10,
	(const void* ) CryptonightR_instruction11,
	(const void* ) CryptonightR_instruction12,
	(const void* ) CryptonightR_instruction13,
	(const void* ) CryptonightR_instruction14,
	(const void* ) CryptonightR_instruction15,
	(const void* ) CryptonightR_instruction16,
	(const void* ) CryptonightR_instruction17,
	(const void* ) CryptonightR_instruction18,
	(const void* ) CryptonightR_instruction19,
	(const void* ) CryptonightR_instruction20,
	(const void* ) CryptonightR_instruction21,
	(const void* ) CryptonightR_instruction22,
	(const void* ) CryptonightR_instruction23,
	(const void* ) CryptonightR_instruction24,
	(const void* ) CryptonightR_instruction25,
	(const void* ) CryptonightR_instruction26,
	(const void* ) CryptonightR_instruction27,
	(const void* ) CryptonightR_instruction28,
	(const void* ) CryptonightR_instruction29,
	(const void* ) CryptonightR_instruction30,
	(const void* ) CryptonightR_instruction31,
	(const void* ) CryptonightR_instruction32,
	(const void* ) CryptonightR_instruction33,
	(const void* ) CryptonightR_instruction34,
	(const void* ) CryptonightR_instruction35,
	(const void* ) CryptonightR_instruction36,
	(const void* ) CryptonightR_instruction37,
	(const void* ) CryptonightR_instruction38,
	(const void* ) CryptonightR_instruction39,
	(const void* ) CryptonightR_instruction40,
	(const void* ) CryptonightR_instruction41,
	(const void* ) CryptonightR_instruction42,
	(const void* ) CryptonightR_instruction43,
	(const void* ) CryptonightR_instruction44,
	(const void* ) CryptonightR_instruction45,
	(const void* ) CryptonightR_instruction46,
	(const void* ) CryptonightR_instruction47,
	(const void* ) CryptonightR_instruction48,
	(const void* ) CryptonightR_instruction49,
	(const void* ) CryptonightR_instruction50,
	(const void* ) CryptonightR_instruction51,
	(const void* ) CryptonightR_instruction52,
	(const void* ) CryptonightR_instruction53,
	(const void* ) CryptonightR_instruction54,
	(const void* ) CryptonightR_instruction55,
	(const void* ) CryptonightR_instruction56,
	(const void* ) CryptonightR_instruction57,
	(const void* ) CryptonightR_instruction58,
	(const void* ) CryptonightR_instruction59,
	(const void* ) CryptonightR_instruction60,
	(const void* ) CryptonightR_instruction61,
	(const void* ) CryptonightR_instruction62,
	(const void* ) CryptonightR_instruction63,
	(const void* ) CryptonightR_instruction64,
	(const void* ) CryptonightR_instruction65,
	(const void* ) CryptonightR_instruction66,
	(const void* ) CryptonightR_instruction67,
	(const void* ) CryptonightR_instruction68,
	(const void* ) CryptonightR_instruction69,
	(const void* ) CryptonightR_instruction70,
	(const void* ) CryptonightR_instruction71,
	(const void* ) CryptonightR_instruction72,
	(const void* ) CryptonightR_instruction73,
	(const void* ) CryptonightR_instruction74,
	(const void* ) CryptonightR_instruction75,
	(const void* ) CryptonightR_instruction76,
	(const void* ) CryptonightR_instruction77,
	(const void* ) CryptonightR_instruction78,
	(const void* ) CryptonightR_instruction79,
	(const void* ) CryptonightR_instruction80,
	(const void* ) CryptonightR_instruction81,
	(const void* ) CryptonightR_instruction82,
	(const void* ) CryptonightR_instruction83,
	(const void* ) CryptonightR_instruction84,
	(const void* ) CryptonightR_instruction85,
	(const void* ) CryptonightR_instruction86,
	(const void* ) CryptonightR_instruction87,
	(const void* ) CryptonightR_instruction88,
	(const void* ) CryptonightR_instruction89,
	(const void* ) CryptonightR_instruction90,
	(const void* ) CryptonightR_instruction91,
	(const void* ) CryptonightR_instruction92,
	(const void* ) CryptonightR_instruction93,
	(const void* ) CryptonightR_instruction94,
	(const void* ) CryptonightR_instruction95,
	(const void* ) CryptonightR_instruction96,
	(const void* ) CryptonightR_instruction97,
	(const void* ) CryptonightR_instruction98,
	(const void* ) CryptonightR_instruction99,
	(const void* ) CryptonightR_instruction100,
	(const void* ) CryptonightR_instruction101,
	(const void* ) CryptonightR_instruction102,
	(const void* ) CryptonightR_instruction103,
	(const void* ) CryptonightR_instruction104,
	(const void* ) CryptonightR_instruction105,
	(const void* ) CryptonightR_instruction106,
	(const void* ) CryptonightR_instruction107,
	(const void* ) CryptonightR_instruction108,
	(const void* ) CryptonightR_instruction109,
	(const void* ) CryptonightR_instruction110,
	(const void* ) CryptonightR_instruction111,
	(const void* ) CryptonightR_instruction112,
	(const void* ) CryptonightR_instruction113,
	(const void* ) CryptonightR_instruction114,
	(const void* ) CryptonightR_instruction115,
	(const void* ) CryptonightR_instruction116,
	(const void* ) CryptonightR_instruction117,
	(const void* ) CryptonightR_instruction118,
	(const void* ) CryptonightR_instruction119,
	(const void* ) CryptonightR_instruction120,
	(const void* ) CryptonightR_instruction121,
	(const void* ) CryptonightR_instruction122,
	(const void* ) CryptonightR_instruction123,
	(const void* ) CryptonightR_instruction124,
	(const void* ) CryptonightR_instruction125,
	(const void* ) CryptonightR_instruction126,
	(const void* ) CryptonightR_instruction127,
	(const void* ) CryptonightR_instruction128,
	(const void* ) CryptonightR_instruction129,
	(const void* ) CryptonightR_instruction130,
	(const void* ) CryptonightR_instruction131,
	(const void* ) CryptonightR_instruction132,
	(const void* ) CryptonightR_instruction133,
	(const void* ) CryptonightR_instruction134,
	(const void* ) CryptonightR_instruction135,
	(const void* ) CryptonightR_instruction136,
	(const void* ) CryptonightR_instruction137,
	(const void* ) CryptonightR_instruction138,
	(const void* ) CryptonightR_instruction139,
	(const void* ) CryptonightR_instruction140,
	(const void* ) CryptonightR_instruction141,
	(const void* ) CryptonightR_instruction142,
	(const void* ) CryptonightR_instruction143,
	(const void* ) CryptonightR_instruction144,
	(const void* ) CryptonightR_instruction145,
	(const void* ) CryptonightR_instruction146,
	(const void* ) CryptonightR_instruction147,
	(const void* ) CryptonightR_instruction148,
	(const void* ) CryptonightR_instruction149,
	(const void* ) CryptonightR_instruction150,
	(const void* ) CryptonightR_instruction151,
	(const void* ) CryptonightR_instruction152,
	(const void* ) CryptonightR_instruction153,
	(const void* ) CryptonightR_instruction154,
	(const void* ) CryptonightR_instruction155,
	(const void* ) CryptonightR_instruction156,
	(const void* ) CryptonightR_instruction157,
	(const void* ) CryptonightR_instruction158,
	(const void* ) CryptonightR_instruction159,
	(const void* ) CryptonightR_instruction160,
	(const void* ) CryptonightR_instruction161,
	(const void* ) CryptonightR_instruction162,
	(const void* ) CryptonightR_instruction163,
	(const void* ) CryptonightR_instruction164,
	(const void* ) CryptonightR_instruction165,
	(const void* ) CryptonightR_instruction166,
	(const void* ) CryptonightR_instruction167,
	(const void* ) CryptonightR_instruction168,
	(const void* ) CryptonightR_instruction169,
	(const void* ) CryptonightR_instruction170,
	(const void* ) CryptonightR_instruction171,
	(const void* ) CryptonightR_instruction172,
	(const void* ) CryptonightR_instruction173,
	(const void* ) CryptonightR_instruction174,
	(const void* ) CryptonightR_instruction175,
	(const void* ) CryptonightR_instruction176,
	(const void* ) CryptonightR_instruction177,
	(const void* ) CryptonightR_instruction178,
	(const void* ) CryptonightR_instruction179,
	(const void* ) CryptonightR_instruction180,
	(const void* ) CryptonightR_instruction181,
	(const void* ) CryptonightR_instruction182,
	(const void* ) CryptonightR_instruction183,
	(const void* ) CryptonightR_instruction184,
	(const void* ) CryptonightR_instruction185,
	(const void* ) CryptonightR_instruction186,
	(const void* ) CryptonightR_instruction187,
	(const void* ) CryptonightR_instruction188,
	(const void* ) CryptonightR_instruction189,
	(const void* ) CryptonightR_instruction190,
	(const void* ) CryptonightR_instruction191,
	(const void* ) CryptonightR_instruction192,
	(const void* ) CryptonightR_instruction193,
	(const void* ) CryptonightR_instruction194,
	(const void* ) CryptonightR_instruction195,
	(const void* ) CryptonightR_instruction196,
	(const void* ) CryptonightR_instruction197,
	(const void* ) CryptonightR_instruction198,
	(const void* ) CryptonightR_instruction199,
	(const void* ) CryptonightR_instruction200,
	(const void* ) CryptonightR_instruction201,
	(const void* ) CryptonightR_instruction202,
	(const void* ) CryptonightR_instruction203,
	(const void* ) CryptonightR_instruction204,
	(const void* ) CryptonightR_instruction205,
	(const void* ) CryptonightR_instruction206,
	(const void* ) CryptonightR_instruction207,
	(const void* ) CryptonightR_instruction208,
	(const void* ) CryptonightR_instruction209,
	(const void* ) CryptonightR_instruction210,
	(const void* ) CryptonightR_instruction211,
	(const void* ) CryptonightR_instruction212,
	(const void* ) CryptonightR_instruction213,
	(const void* ) CryptonightR_instruction214,
	(const void* ) CryptonightR_instruction215,
	(const void* ) CryptonightR_instruction216,
	(const void* ) CryptonightR_instruction217,
	(const void* ) CryptonightR_instruction218,
	(const void* ) CryptonightR_instruction219,
	(const void* ) CryptonightR_instruction220,
	(const void* ) CryptonightR_instruction221,
	(const void* ) CryptonightR_instruction222,
	(const void* ) CryptonightR_instruction223,
	(const void* ) CryptonightR_instruction224,
	(const void* ) CryptonightR_instruction225,
	(const void* ) CryptonightR_instruction226,
	(const void* ) CryptonightR_instruction227,
	(const void* ) CryptonightR_instruction228,
	(const void* ) CryptonightR_instruction229,
	(const void* ) CryptonightR_instruction230,
	(const void* ) CryptonightR_instruction231,
	(const void* ) CryptonightR_instruction232,
	(const void* ) CryptonightR_instruction233,
	(const void* ) CryptonightR_instruction234,
	(const void* ) CryptonightR_instruction235,
	(const void* ) CryptonightR_instruction236,
	(const void* ) CryptonightR_instruction237,
	(const void* ) CryptonightR_instruction238,
	(const void* ) CryptonightR_instruction239,
	(const void* ) CryptonightR_instruction240,
	(const void* ) CryptonightR_instruction241,
	(const void* ) CryptonightR_instruction242,
	(const void* ) CryptonightR_instruction243,
	(const void* ) CryptonightR_instruction244,
	(const void* ) CryptonightR_instruction245,
	(const void* ) CryptonightR_instruction246,
	(const void* ) CryptonightR_instruction247,
	(const void* ) CryptonightR_instruction248,
	(const void* ) CryptonightR_instruction249,
	(const void* ) CryptonightR_instruction250,
	(const void* ) CryptonightR_instruction251,
	(const void* ) CryptonightR_instruction252,
	(const void* ) CryptonightR_instruction253,
	(const void* ) CryptonightR_instruction254,
	(const void* ) CryptonightR_instruction255,
	(const void* ) CryptonightR_instruction256,
};

const void* instructions_mov[257] = {
	(const void* ) CryptonightR_instruction_mov0,
	(const void* ) CryptonightR_instruction_mov1,
	(const void* ) CryptonightR_instruction_mov2,
	(const void* ) CryptonightR_instruction_mov3,
	(const void* ) CryptonightR_instruction_mov4,
	(const void* ) CryptonightR_instruction_mov5,
	(const void* ) CryptonightR_instruction_mov6,
	(const void* ) CryptonightR_instruction_mov7,
	(const void* ) CryptonightR_instruction_mov8,
	(const void* ) CryptonightR_instruction_mov9,
	(const void* ) CryptonightR_instruction_mov10,
	(const void* ) CryptonightR_instruction_mov11,
	(const void* ) CryptonightR_instruction_mov12,
	(const void* ) CryptonightR_instruction_mov13,
	(const void* ) CryptonightR_instruction_mov14,
	(const void* ) CryptonightR_instruction_mov15,
	(const void* ) CryptonightR_instruction_mov16,
	(const void* ) CryptonightR_instruction_mov17,
	(const void* ) CryptonightR_instruction_mov18,
	(const void* ) CryptonightR_instruction_mov19,
	(const void* ) CryptonightR_instruction_mov20,
	(const void* ) CryptonightR_instruction_mov21,
	(const void* ) CryptonightR_instruction_mov22,
	(const void* ) CryptonightR_instruction_mov23,
	(const void* ) CryptonightR_instruction_mov24,
	(const void* ) CryptonightR_instruction_mov25,
	(const void* ) CryptonightR_instruction_mov26,
	(const void* ) CryptonightR_instruction_mov27,
	(const void* ) CryptonightR_instruction_mov28,
	(const void* ) CryptonightR_instruction_mov29,
	(const void* ) CryptonightR_instruction_mov30,
	(const void* ) CryptonightR_instruction_mov31,
	(const void* ) CryptonightR_instruction_mov32,
	(const void* ) CryptonightR_instruction_mov33,
	(const void* ) CryptonightR_instruction_mov34,
	(const void* ) CryptonightR_instruction_mov35,
	(const void* ) CryptonightR_instruction_mov36,
	(const void* ) CryptonightR_instruction_mov37,
	(const void* ) CryptonightR_instruction_mov38,
	(const void* ) CryptonightR_instruction_mov39,
	(const void* ) CryptonightR_instruction_mov40,
	(const void* ) CryptonightR_instruction_mov41,
	(const void* ) CryptonightR_instruction_mov42,
	(const void* ) CryptonightR_instruction_mov43,
	(const void* ) CryptonightR_instruction_mov44,
	(const void* ) CryptonightR_instruction_mov45,
	(const void* ) CryptonightR_instruction_mov46,
	(const void* ) CryptonightR_instruction_mov47,
	(const void* ) CryptonightR_instruction_mov48,
	(const void* ) CryptonightR_instruction_mov49,
	(const void* ) CryptonightR_instruction_mov50,
	(const void* ) CryptonightR_instruction_mov51,
	(const void* ) CryptonightR_instruction_mov52,
	(const void* ) CryptonightR_instruction_mov53,
	(const void* ) CryptonightR_instruction_mov54,
	(const void* ) CryptonightR_instruction_mov55,
	(const void* ) CryptonightR_instruction_mov56,
	(const void* ) CryptonightR_instruction_mov57,
	(const void* ) CryptonightR_instruction_mov58,
	(const void* ) CryptonightR_instruction_mov59,
	(const void* ) CryptonightR_instruction_mov60,
	(const void* ) CryptonightR_instruction_mov61,
	(const void* ) CryptonightR_instruction_mov62,
	(const void* ) CryptonightR_instruction_mov63,
	(const void* ) CryptonightR_instruction_mov64,
	(const void* ) CryptonightR_instruction_mov65,
	(const void* ) CryptonightR_instruction_mov66,
	(const void* ) CryptonightR_instruction_mov67,
	(const void* ) CryptonightR_instruction_mov68,
	(const void* ) CryptonightR_instruction_mov69,
	(const void* ) CryptonightR_instruction_mov70,
	(const void* ) CryptonightR_instruction_mov71,
	(const void* ) CryptonightR_instruction_mov72,
	(const void* ) CryptonightR_instruction_mov73,
	(const void* ) CryptonightR_instruction_mov74,
	(const void* ) CryptonightR_instruction_mov75,
	(const void* ) CryptonightR_instruction_mov76,
	(const void* ) CryptonightR_instruction_mov77,
	(const void* ) CryptonightR_instruction_mov78,
	(const void* ) CryptonightR_instruction_mov79,
	(const void* ) CryptonightR_instruction_mov80,
	(const void* ) CryptonightR_instruction_mov81,
	(const void* ) CryptonightR_instruction_mov82,
	(const void* ) CryptonightR_instruction_mov83,
	(const void* ) CryptonightR_instruction_mov84,
	(const void* ) CryptonightR_instruction_mov85,
	(const void* ) CryptonightR_instruction_mov86,
	(const void* ) CryptonightR_instruction_mov87,
	(const void* ) CryptonightR_instruction_mov88,
	(const void* ) CryptonightR_instruction_mov89,
	(const void* ) CryptonightR_instruction_mov90,
	(const void* ) CryptonightR_instruction_mov91,
	(const void* ) CryptonightR_instruction_mov92,
	(const void* ) CryptonightR_instruction_mov93,
	(const void* ) CryptonightR_instruction_mov94,
	(const void* ) CryptonightR_instruction_mov95,
	(const void* ) CryptonightR_instruction_mov96,
	(const void* ) CryptonightR_instruction_mov97,
	(const void* ) CryptonightR_instruction_mov98,
	(const void* ) CryptonightR_instruction_mov99,
	(const void* ) CryptonightR_instruction_mov100,
	(const void* ) CryptonightR_instruction_mov101,
	(const void* ) CryptonightR_instruction_mov102,
	(const void* ) CryptonightR_instruction_mov103,
	(const void* ) CryptonightR_instruction_mov104,
	(const void* ) CryptonightR_instruction_mov105,
	(const void* ) CryptonightR_instruction_mov106,
	(const void* ) CryptonightR_instruction_mov107,
	(const void* ) CryptonightR_instruction_mov108,
	(const void* ) CryptonightR_instruction_mov109,
	(const void* ) CryptonightR_instruction_mov110,
	(const void* ) CryptonightR_instruction_mov111,
	(const void* ) CryptonightR_instruction_mov112,
	(const void* ) CryptonightR_instruction_mov113,
	(const void* ) CryptonightR_instruction_mov114,
	(const void* ) CryptonightR_instruction_mov115,
	(const void* ) CryptonightR_instruction_mov116,
	(const void* ) CryptonightR_instruction_mov117,
	(const void* ) CryptonightR_instruction_mov118,
	(const void* ) CryptonightR_instruction_mov119,
	(const void* ) CryptonightR_instruction_mov120,
	(const void* ) CryptonightR_instruction_mov121,
	(const void* ) CryptonightR_instruction_mov122,
	(const void* ) CryptonightR_instruction_mov123,
	(const void* ) CryptonightR_instruction_mov124,
	(const void* ) CryptonightR_instruction_mov125,
	(const void* ) CryptonightR_instruction_mov126,
	(const void* ) CryptonightR_instruction_mov127,
	(const void* ) CryptonightR_instruction_mov128,
	(const void* ) CryptonightR_instruction_mov129,
	(const void* ) CryptonightR_instruction_mov130,
	(const void* ) CryptonightR_instruction_mov131,
	(const void* ) CryptonightR_instruction_mov132,
	(const void* ) CryptonightR_instruction_mov133,
	(const void* ) CryptonightR_instruction_mov134,
	(const void* ) CryptonightR_instruction_mov135,
	(const void* ) CryptonightR_instruction_mov136,
	(const void* ) CryptonightR_instruction_mov137,
	(const void* ) CryptonightR_instruction_mov138,
	(const void* ) CryptonightR_instruction_mov139,
	(const void* ) CryptonightR_instruction_mov140,
	(const void* ) CryptonightR_instruction_mov141,
	(const void* ) CryptonightR_instruction_mov142,
	(const void* ) CryptonightR_instruction_mov143,
	(const void* ) CryptonightR_instruction_mov144,
	(const void* ) CryptonightR_instruction_mov145,
	(const void* ) CryptonightR_instruction_mov146,
	(const void* ) CryptonightR_instruction_mov147,
	(const void* ) CryptonightR_instruction_mov148,
	(const void* ) CryptonightR_instruction_mov149,
	(const void* ) CryptonightR_instruction_mov150,
	(const void* ) CryptonightR_instruction_mov151,
	(const void* ) CryptonightR_instruction_mov152,
	(const void* ) CryptonightR_instruction_mov153,
	(const void* ) CryptonightR_instruction_mov154,
	(const void* ) CryptonightR_instruction_mov155,
	(const void* ) CryptonightR_instruction_mov156,
	(const void* ) CryptonightR_instruction_mov157,
	(const void* ) CryptonightR_instruction_mov158,
	(const void* ) CryptonightR_instruction_mov159,
	(const void* ) CryptonightR_instruction_mov160,
	(const void* ) CryptonightR_instruction_mov161,
	(const void* ) CryptonightR_instruction_mov162,
	(const void* ) CryptonightR_instruction_mov163,
	(const void* ) CryptonightR_instruction_mov164,
	(const void* ) CryptonightR_instruction_mov165,
	(const void* ) CryptonightR_instruction_mov166,
	(const void* ) CryptonightR_instruction_mov167,
	(const void* ) CryptonightR_instruction_mov168,
	(const void* ) CryptonightR_instruction_mov169,
	(const void* ) CryptonightR_instruction_mov170,
	(const void* ) CryptonightR_instruction_mov171,
	(const void* ) CryptonightR_instruction_mov172,
	(const void* ) CryptonightR_instruction_mov173,
	(const void* ) CryptonightR_instruction_mov174,
	(const void* ) CryptonightR_instruction_mov175,
	(const void* ) CryptonightR_instruction_mov176,
	(const void* ) CryptonightR_instruction_mov177,
	(const void* ) CryptonightR_instruction_mov178,
	(const void* ) CryptonightR_instruction_mov179,
	(const void* ) CryptonightR_instruction_mov180,
	(const void* ) CryptonightR_instruction_mov181,
	(const void* ) CryptonightR_instruction_mov182,
	(const void* ) CryptonightR_instruction_mov183,
	(const void* ) CryptonightR_instruction_mov184,
	(const void* ) CryptonightR_instruction_mov185,
	(const void* ) CryptonightR_instruction_mov186,
	(const void* ) CryptonightR_instruction_mov187,
	(const void* ) CryptonightR_instruction_mov188,
	(const void* ) CryptonightR_instruction_mov189,
	(const void* ) CryptonightR_instruction_mov190,
	(const void* ) CryptonightR_instruction_mov191,
	(const void* ) CryptonightR_instruction_mov192,
	(const void* ) CryptonightR_instruction_mov193,
	(const void* ) CryptonightR_instruction_mov194,
	(const void* ) CryptonightR_instruction_mov195,
	(const void* ) CryptonightR_instruction_mov196,
	(const void* ) CryptonightR_instruction_mov197,
	(const void* ) CryptonightR_instruction_mov198,
	(const void* ) CryptonightR_instruction_mov199,
	(const void* ) CryptonightR_instruction_mov200,
	(const void* ) CryptonightR_instruction_mov201,
	(const void* ) CryptonightR_instruction_mov202,
	(const void* ) CryptonightR_instruction_mov203,
	(const void* ) CryptonightR_instruction_mov204,
	(const void* ) CryptonightR_instruction_mov205,
	(const void* ) CryptonightR_instruction_mov206,
	(const void* ) CryptonightR_instruction_mov207,
	(const void* ) CryptonightR_instruction_mov208,
	(const void* ) CryptonightR_instruction_mov209,
	(const void* ) CryptonightR_instruction_mov210,
	(const void* ) CryptonightR_instruction_mov211,
	(const void* ) CryptonightR_instruction_mov212,
	(const void* ) CryptonightR_instruction_mov213,
	(const void* ) CryptonightR_instruction_mov214,
	(const void* ) CryptonightR_instruction_mov215,
	(const void* ) CryptonightR_instruction_mov216,
	(const void* ) CryptonightR_instruction_mov217,
	(const void* ) CryptonightR_instruction_mov218,
	(const void* ) CryptonightR_instruction_mov219,
	(const void* ) CryptonightR_instruction_mov220,
	(const void* ) CryptonightR_instruction_mov221,
	(const void* ) CryptonightR_instruction_mov222,
	(const void* ) CryptonightR_instruction_mov223,
	(const void* ) CryptonightR_instruction_mov224,
	(const void* ) CryptonightR_instruction_mov225,
	(const void* ) CryptonightR_instruction_mov226,
	(const void* ) CryptonightR_instruction_mov227,
	(const void* ) CryptonightR_instruction_mov228,
	(const void* ) CryptonightR_instruction_mov229,
	(const void* ) CryptonightR_instruction_mov230,
	(const void* ) CryptonightR_instruction_mov231,
	(const void* ) CryptonightR_instruction_mov232,
	(const void* ) CryptonightR_instruction_mov233,
	(const void* ) CryptonightR_instruction_mov234,
	(const void* ) CryptonightR_instruction_mov235,
	(const void* ) CryptonightR_instruction_mov236,
	(const void* ) CryptonightR_instruction_mov237,
	(const void* ) CryptonightR_instruction_mov238,
	(const void* ) CryptonightR_instruction_mov239,
	(const void* ) CryptonightR_instruction_mov240,
	(const void* ) CryptonightR_instruction_mov241,
	(const void* ) CryptonightR_instruction_mov242,
	(const void* ) CryptonightR_instruction_mov243,
	(const void* ) CryptonightR_instruction_mov244,
	(const void* ) CryptonightR_instruction_mov245,
	(const void* ) CryptonightR_instruction_mov246,
	(const void* ) CryptonightR_instruction_mov247,
	(const void* ) CryptonightR_instruction_mov248,
	(const void* ) CryptonightR_instruction_mov249,
	(const void* ) CryptonightR_instruction_mov250,
	(const void* ) CryptonightR_instruction_mov251,
	(const void* ) CryptonightR_instruction_mov252,
	(const void* ) CryptonightR_instruction_mov253,
	(const void* ) CryptonightR_instruction_mov254,
	(const void* ) CryptonightR_instruction_mov255,
	(const void* ) CryptonightR_instruction_mov256,
};

#endif

#endif // CRYPTONIGHTR_TEMPLATE_H
